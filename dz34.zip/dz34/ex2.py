import threading
import time

# Функция для вычисления факториала
def factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Функция для запуска вычисления факториала в отдельном потоке
def calculate_factorial(n):
    print(f"Вычисление факториала числа {n} начато.")
    time.sleep(1) # Имитация работы
    fact = factorial(n)
    print(f"Факториал числа {n}: {fact}")

if __name__ == '__main__':
    # Число для вычисления факториала
    number = 10

    # Создаем три потока
    t1 = threading.Thread(target=calculate_factorial, args=(number,))
    t2 = threading.Thread(target=calculate_factorial, args=(number - 1,))
    t3 = threading.Thread(target=calculate_factorial, args=(number - 2,))

    # Запускаем потоки
    t1.start()
    t2.start()
    t3.start()

    # Дожидаемся завершения потоков
    t1.join()
    t2.join()
    t3.join()
