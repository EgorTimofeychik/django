import threading

# Функция для поиска и печати четных чисел
def print_even_numbers():
    even_numbers = [num for num in range(10, 101) if num % 2 == 0]
    print("Четные числа:", even_numbers)

# Функция для поиска и печати нечетных чисел
def print_odd_numbers():
    odd_numbers = [num for num in range(10, 101) if num % 2 != 0]
    print("Нечетные числа:", odd_numbers)

if __name__ == '__main__':
    # Создание потоков
    t1 = threading.Thread(target=print_even_numbers)
    t2 = threading.Thread(target=print_odd_numbers)

    # Запуск потоков
    t1.start()
    t2.start()

    # Дожидаемся завершения потоков
    t1.join()
    t2.join()
