from django.shortcuts import render
from django.http import HttpResponse
from .forms import PostForm

def page1(request):
    return render(request, 'app1/page1.html')

def page2(request):
    return render(request, 'app1/page2.html')

def tab1(request):
    if request.method == "POST":
        new_post = PostForm(request.POST)
        if new_post.is_valid():
            new_post.save( )
    post_form = PostForm()
    return render(request, "first_post.html", {"comment_form": post_form})

def tab2(request):
    return render(request, "second_post.html", {})
