from django.forms import ModelForm
from .models import Post

from django import forms


class MyForm(forms.Form):
    nickname = forms.CharField(
        label="your nickname",
        max_length=20,
        widget=forms.TextInput(attrs={"class": "form-group"})
        )
    email = forms.EmailField(
        label="email", widget=forms.TextInput(attrs={"class": "form-group"})
        )
    commment = forms.CharField(
        label="commment", widget=forms.Textarea(attrs={"class": "form-group"})
        )



class PostForm(ModelForm):
    class Meta:
        model = Post
        fields = "__all__"