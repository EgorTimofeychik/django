from django.urls import path
from . import views

urlpatterns = [
    path('page1/', views.page1, name='page1'),
    path('page2/', views.page2, name='page2'),
    path('tab1', views.tab1),
    path('tab2', views.tab2),
    path('post/create/', views.create_post, name='create_post'),
    path('post/<int:post_id>/', views.read_post, name='read_post'),
    path('post/<int:post_id>/update/', views.update_post, name='update_post'),
    path('post/<int:post_id>/delete/', views.delete_post, name='delete_post'),
    path('app1/', include('app1.urls')),
    ]