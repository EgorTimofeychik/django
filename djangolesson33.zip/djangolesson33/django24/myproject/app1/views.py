from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from .forms import PostForm
from .models import Post
import multiprocessing

def my_function():
    print("This function is running in a separate process")

if __name__ == '__main__':
    processes = []
    for _ in range(3):
        process = multiprocessing.Process(target=my_function)
        process.start()
        processes.append(process)

    for process in processes:
        process.join()
        
def page1(request):
    return render(request, 'app1/page1.html')

def page2(request):
    return render(request, 'app1/page2.html')

def tab1(request):
    if request.method == "POST":
        new_post = PostForm(request.POST)
        if new_post.is_valid():
            new_post.save()
    post_form = PostForm()
    return render(request, "first_post.html", {"comment_form": post_form})

def tab2(request):
    return render(request, "second_post.html", {})

def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('post_list')
    else:
        form = PostForm()
    return render(request, 'create_post.html', {'form': form})

def read_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    return render(request, 'read_post.html', {'post': post})

def update_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    form = PostForm(request.POST or None, instance=post)
    if form.is_valid():
        form.save()
        return redirect('post_list')
    return render(request, 'update_post.html', {'form': form, 'post': post})

def delete_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        post.delete()
        return redirect('post_list')
    return render(request, 'delete_post.html', {'post': post})

def post_list(request):
    posts = Post.objects.all()
    return render(request, 'post_list.html', {'posts': posts})
