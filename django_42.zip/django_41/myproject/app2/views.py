from django.shortcuts import render
import threading

def my_function():
    print("This function is running in a separate thread")

if __name__ == '__main__':
    threads = []
    for _ in range(3):
        thread = threading.Thread(target=my_function)
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

def page1(request):
    return render(request, 'app2/page1.html')

def page2(request):
    return render(request, 'app2/page2.html')
